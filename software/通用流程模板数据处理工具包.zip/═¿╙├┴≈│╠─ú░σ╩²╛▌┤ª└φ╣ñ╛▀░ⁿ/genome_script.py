#!/usr/bin/python
# -*- coding: UTF-8 -*-

import numpy as np
import pandas as pd
import math

#WGD基因甲基化水平计算
def WGD_mythyl_level(WGD_list, CG_level, CHG_level, CHH_level, WGD_CG_result, WGD_CHG_result, WGD_CHH_result):
    '''
    WGD_list:物种的WGD文件路径，文件每列以\n,\t,空格分隔。
    第一行为表头，每一列分别为：基因1名称、基因1染色体编号、基因1坐标起点、基因1坐标终点、基因2编号、基因2染色体编号、基因2坐标起点、基因2坐标终点

    CG(/CHG/CHH)_level：为甲基化水平文件路径。文件以，为分隔符。
    文件有表头，为“Lachesis_group_ID、Coordinate、Value”，每一列分别是：染色体编号、甲基化在染色体上的碱基位点编号、甲基化水平。

    WGD_CG(/CHG/CHH)_result：为WGD基因甲基化水平结果文件路径。
    每一列分别为：基因1名称、基因1染色体编号、基因1坐标起点、基因1坐标终点、基因1甲基化总量、基因1甲基化平均值、基因2编号、基因2染色体编号、基因2坐标起点、基因2坐标终点、基因2甲基化总量、基因2甲基化平均值
    '''
    #读入WGD列表
    WGD_List = open(WGD_list,"r")
    
    #创建/打开WGD_CG/CHG/CHH值的文件，并写入表头
    WGD_CG_Result = open(WGD_CG_result,"w+")
    WGD_CG_Result.writelines("gene_1"+'\t'+"position_1"+'\t'+"start_1"+'\t'+"end_1"+'\t'+"CG_sum_1"+'\t'+"CG_avg_1"+'\t'+"gene_2"+'\t'+"position_2"+'\t'+"start_2"+'\t'+"end_2"+'\t'+"CG_sum_2"+'\t' +"CG_avg_2"+'\n')
    WGD_CHG_Result = open(WGD_CHG_result,"w+")
    WGD_CHG_Result.writelines("gene_1"+'\t'+"position_1"+'\t'+"start_1"+'\t'+"end_1"+'\t'+"CHG_sum_1"+'\t'+"CHG_avg_1"+'\t'+"gene_2"+'\t'+"position_2"+'\t'+"start_2"+'\t'+"end_2"+'\t'+"CHG_sum_2"+'\t' +"CHG_avg_2"+'\n')
    WGD_CHH_Result = open(WGD_CHH_result,"w+")
    WGD_CHH_Result.writelines("gene_1"+'\t'+"position_1"+'\t'+"start_1"+'\t'+"end_1"+'\t'+"CHH_sum_1"+'\t'+"CHH_avg_1"+'\t'+"gene_2"+'\t'+"position_2"+'\t'+"start_2"+'\t'+"end_2"+'\t'+"CHH_sum_2"+'\t' +"CHH_avg_2"+'\n')
    
    #构建甲基化数据集
    CG_df=pd.read_csv(CG_level,engine='python',header = 0,sep='\t')
    print("CG甲基化数据集构建完成，长度：%d"%len(CG_df))
    CHG_df=pd.read_csv(CHG_level,engine='python',header = 0,sep='\t')
    print("CHG甲基化数据集构建完成，长度：%d"%len(CHG_df))
    CHH_df=pd.read_csv(CHH_level,engine='python',header = 0,sep='\t')
    print("CHH甲基化数据集构建完成，长度：%d"%len(CHH_df))
    
    #计算WGD甲基化水平
    next(WGD_List)
    line_count = 0
    for line in WGD_List:

        WGD_list = line.strip().split()

        left_group = WGD_list[1]
        left_start_coord = int(WGD_list[2])
        left_end_coord = int(WGD_list[3])

        right_group = WGD_list[5]
        right_start_coord = int(WGD_list[6])
        right_end_coord = int(WGD_list[7])

        left_CG_temp_df = CG_df[(CG_df['Lachesis_group_ID']==left_group) & (CG_df['Coordinate']>=left_start_coord) & (CG_df['Coordinate']<=left_end_coord)]
        left_CG_mean = left_CG_temp_df['Value'].mean()
        left_CG_sum = left_CG_temp_df['Value'].sum()

        right_CG_temp_df = CG_df[(CG_df['Lachesis_group_ID'] == right_group) & (CG_df['Coordinate'] >= right_start_coord) & (CG_df['Coordinate'] <= right_end_coord)]
        right_CG_mean = right_CG_temp_df['Value'].mean()
        right_CG_sum = right_CG_temp_df['Value'].sum()

        left_CHG_temp_df = CHG_df[(CHG_df['Lachesis_group_ID']==left_group) & (CHG_df['Coordinate']>=left_start_coord) & (CHG_df['Coordinate']<=left_end_coord)]
        left_CHG_mean = left_CHG_temp_df['Value'].mean()
        left_CHG_sum = left_CHG_temp_df['Value'].sum()

        right_CHG_temp_df = CHG_df[(CHG_df['Lachesis_group_ID'] == right_group) & (CHG_df['Coordinate'] >= right_start_coord) & (CHG_df['Coordinate'] <= right_end_coord)]
        right_CHG_mean = right_CHG_temp_df['Value'].mean()
        right_CHG_sum = right_CHG_temp_df['Value'].sum()

        left_CHH_temp_df = CHH_df[(CHH_df['Lachesis_group_ID']==left_group) & (CHH_df['Coordinate']>=left_start_coord) & (CHH_df['Coordinate']<=left_end_coord)]
        left_CHH_mean = left_CHH_temp_df['Value'].mean()
        left_CHH_sum = left_CHH_temp_df['Value'].sum()

        right_CHH_temp_df = CHH_df[(CHH_df['Lachesis_group_ID'] == right_group) & (CHH_df['Coordinate'] >= right_start_coord) & (CHH_df['Coordinate'] <= right_end_coord)]
        right_CHH_mean = right_CHH_temp_df['Value'].mean()
        right_CHH_sum = right_CHH_temp_df['Value'].sum()

        WGD_CG_Result.writelines(WGD_list[0] + '\t' + WGD_list[1] + '\t' + WGD_list[2] + '\t' + WGD_list[3] + '\t%f'%left_CG_sum + '\t%f'%left_CG_mean + '\t' + WGD_list[4] + '\t' + WGD_list[5] + '\t' + WGD_list[6] + '\t' + WGD_list[7] + '\t%f'%right_CG_sum+ '\t%f'%right_CG_mean + '\n')
        WGD_CHG_Result.writelines(WGD_list[0] + '\t' + WGD_list[1] + '\t' + WGD_list[2] + '\t' + WGD_list[3] + '\t%f'%left_CHG_sum + '\t%f'%left_CHG_mean + '\t' + WGD_list[4] + '\t' + WGD_list[5] + '\t' + WGD_list[6] + '\t' + WGD_list[7] + '\t%f'%right_CHG_sum+ '\t%f'%right_CHG_mean + '\n')
        WGD_CHH_Result.writelines(WGD_list[0] + '\t' + WGD_list[1] + '\t' + WGD_list[2] + '\t' + WGD_list[3] + '\t%f'%left_CHH_sum + '\t%f'%left_CHH_mean + '\t' + WGD_list[4] + '\t' + WGD_list[5] + '\t' + WGD_list[6] + '\t' + WGD_list[7] + '\t%f'%right_CHH_sum+ '\t%f'%right_CHH_mean + '\n')

        line_count = line_count+1
        print("line:%d"%line_count)

    WGD_List.close()
    WGD_CG_Result.close()
    WGD_CHG_Result.close()
    WGD_CHH_Result.close()


#TAD边界甲基化水平
def TAD_bound_mythyl_level(Chr_length, TAD_list, CG_level, CHG_level, CHH_level, Window_num, Window_size, TAD_bound_CG_result, TAD_bound_CHG_result, TAD_bound_CHH_result):
    '''
    Chr_length（无表头）:染色体编号、染色体长度
    TAD_list（第一行为表头）：染色体编号、start坐标、end坐标
    CG(/CHG/CHH)_level：为甲基化水平文件路径。文件以，为分隔符；
    文件有表头，为“Lachesis_group_ID、Coordinate、Value”，每一列分别是：染色体编号、甲基化在染色体上的碱基位点编号、甲基化水平。
    TAD_bound_CG(/CHG/CHH)_result：CG(/CHG/CHH)值.................
    '''
    
    #读入染色体长度数据
    chr_length_list=open(Chr_length,"r")
    #读入TAD坐标列表
    TAD_List = open(TAD_list,"r")
    
    #输出TAD边界处CG/CHG/CHH值列表
    TAD_CG_Result = open(TAD_bound_CG_result,"w+")
    TAD_CHG_Result = open(TAD_bound_CHG_result,"w+")
    TAD_CHH_Result = open(TAD_bound_CHH_result,"w+")
    
    #构建染色体长度字典
    chr_len_dic={}
    for line in chr_length_list:
        linelist = line.strip().split()
        chr_len_dic[linelist[0]] = linelist[1]
    print(chr_len_dic)
    print("染色体长度字典构建完成，长度：%d"%len(chr_len_dic))
    
    #构建CG/CHG/CHH甲基化数据集
    CG_df = pd.read_csv(CG_level,engine='python',header = 0,sep='\t')
    print("CG数据集构建完成，长度：%d"%len(CG_df))
    CHG_df = pd.read_csv(CHG_level,engine='python',header = 0,sep='\t')
    print("CHG数据集构建完成，长度：%d"%len(CHG_df))
    CHH_df = pd.read_csv(CHH_level,engine='python',header = 0,sep='\t')
    print("CHH数据集构建完成，长度：%d"%len(CHH_df))
    
    #计算TAD边界甲基化水平
    TAD_count = 0
    
    for line in TAD_List:
        TAD_line = line.strip().split()
        chr = TAD_line[0]
        chr_length = int(chr_len_dic[chr])

        #滑动窗口初始坐标
        window_start = int(TAD_line[1])-int(Window_num*Window_size/2)
        window_end = window_start+Window_size

        #初始化甲基化水平
        CG = "-"
        CHG = "-"
        CHH = "-"
        final_start_coord = 0
        final_end_coord = 0

        #计算每个窗口的甲基化水平
        for i in range(0,Window_num):
            if(i<(Window_num-1)):
                if(window_end<=0 or window_start> chr_length):
                    TAD_CG_Result.writelines(CG+'\t')
                    TAD_CHG_Result.writelines(CHG + '\t')
                    TAD_CHH_Result.writelines(CHH + '\t')

                else:
                    if(window_start<=0 and window_end>0 and window_end<=chr_length):
                        final_start_coord = 0
                        final_end_coord = window_end
                    if(window_start>0 and window_end <=chr_length):
                        final_start_coord = window_start
                        final_end_coord = window_end
                    if(window_start>0 and window_end>chr_length):
                        final_start_coord = window_start
                        final_end_coord = chr_length

                    temp_CG_df = CG_df[(CG_df['Lachesis_group_ID']==chr) & (CG_df['Coordinate']>=final_start_coord) & (CG_df['Coordinate']<=final_end_coord)]
                    CG_mean = temp_CG_df['Value'].mean()
                    if (str(CG_mean) == 'nan'):
                        CG_mean = 0

                    temp_CHG_df = CHG_df[(CHG_df['Lachesis_group_ID'] == chr) & (CHG_df['Coordinate'] >= final_start_coord) & (CHG_df['Coordinate'] <= final_end_coord)]
                    CHG_mean = temp_CHG_df['Value'].mean()
                    if (str(CHG_mean) == 'nan'):
                        CHG_mean = 0

                    temp_CHH_df = CHH_df[(CHH_df['Lachesis_group_ID'] == chr) & (CHH_df['Coordinate'] >= final_start_coord) & (CHH_df['Coordinate'] <= final_end_coord)]
                    CHH_mean = temp_CHH_df['Value'].mean()
                    if (str(CHH_mean) == 'nan'):
                        CHH_mean = 0

                    CG = str(CG_mean)
                    CHG = str(CHG_mean)
                    CHH = str(CHH_mean)

                    TAD_CG_Result.writelines(CG + '\t')
                    TAD_CHG_Result.writelines(CHG + '\t')
                    TAD_CHH_Result.writelines(CHH + '\t')

            else:
                if(window_end<=0 or window_start> chr_length):
                    TAD_CG_Result.writelines(CG+'\n')
                    TAD_CHG_Result.writelines(CHG + '\n')
                    TAD_CHH_Result.writelines(CHH + '\n')

                else:
                    if(window_start<=0 and window_end>0 and window_end<=chr_length):
                        final_start_coord = 0
                        final_end_coord = window_end
                    if(window_start>0 and window_end <=chr_length):
                        final_start_coord = window_start
                        final_end_coord = window_end
                    if(window_start>0 and window_end>chr_length):
                        final_start_coord = window_start
                        final_end_coord = chr_length

                    temp_CG_df = CG_df[(CG_df['Lachesis_group_ID']==chr) & (CG_df['Coordinate']>=final_start_coord) & (CG_df['Coordinate']<=final_end_coord)]
                    CG_mean = temp_CG_df['Value'].mean()
                    if (str(CG_mean) == 'nan'):
                        CG_mean = 0

                    temp_CHG_df = CHG_df[(CHG_df['Lachesis_group_ID'] == chr) & (CHG_df['Coordinate'] >= final_start_coord) & (CHG_df['Coordinate'] <= final_end_coord)]
                    CHG_mean = temp_CHG_df['Value'].mean()
                    if (str(CHG_mean) == 'nan'):
                        CHG_mean = 0

                    temp_CHH_df = CHH_df[(CHH_df['Lachesis_group_ID'] == chr) & (CHH_df['Coordinate'] >= final_start_coord) & (CHH_df['Coordinate'] <= final_end_coord)]
                    CHH_mean = temp_CHH_df['Value'].mean()
                    if (str(CHH_mean) == 'nan'):
                        CHH_mean = 0

                    CG = str(CG_mean)
                    CHG = str(CHG_mean)
                    CHH = str(CHH_mean)

                    TAD_CG_Result.writelines(CG + '\n')
                    TAD_CHG_Result.writelines(CHG + '\n')
                    TAD_CHH_Result.writelines(CHH + '\n')

            window_start = window_start+Window_size
            window_end = window_end+Window_size
            pass
        TAD_count = TAD_count +1
        print("TAD_line:%d"%TAD_count)
    chr_length_list.close()
    TAD_List.close()
    TAD_CG_Result.close()
    TAD_CHG_Result.close()
    TAD_CHH_Result.close()


#基因compartment判断
def gene_comp_judge(AB_comp_list, Gene_list, Gene_comp_result, Resolution):
    '''
    AB_comp_list（无表头）:染色体编号、start坐标、end坐标、AB区室（A/B/NA）
    Gene_list（有表头）：基因编号、染色体编号、strand、基因开始坐标、基因结束坐标、bin开始坐标、bin结束坐标、基因跨越的bin数、基因长度、TPM
    Gene_comp_result（有表头）：基因编号、染色体编号、strand、基因开始坐标、基因结束坐标、bin开始坐标、bin结束坐标、基因跨越的bin数、基因长度、TPM、Compartment结果（A/B）
    Resolution:分析所用的矩阵数据的分辨率
    '''
    
    #compartment文件读入
    AB_list=open(AB_comp_list, "r")
    
    #基因列表读入
    gene_list = open(Gene_list, "r")
    
    #输出基因对应compartment结果
    gene_compartment_list=open(Gene_comp_result,"w+")
    gene_compartment_list.writelines("Gene ID\tReference\tStrand\tStart\tEnd\tBin_start\tBin_end\tBin_count\tLength\tTPM\tCompartment"+'\n')
    
    #构建compartment字典
    AB_dic = {}
    for line in AB_list:
        linelist = line.strip().split('\t')
        bin_coord = linelist[0]+'-'+linelist[1]
        AB_dic[bin_coord] = linelist[3]
    print("Compartment字典构建完成，长度%d"%len(AB_dic))
    
    #输出基因对应Compartment结果
    next(gene_list)
    line_count = 0
    for line in gene_list:
        linelist = line.strip().split()
        #初始化Compartmen标记
        gene_comp_A = 0
        gene_comp_B = 0
        gene_comp_NA = 0
        for i in range(0,int(linelist[7])):
            gene_bin_coord = linelist[1]+"-"+str(int(linelist[5])+(i*Resolution))
            if (AB_dic[gene_bin_coord] == 'A'):
                gene_comp_A = 1
            if (AB_dic[gene_bin_coord] == 'B'):
                gene_comp_B = 1
            if (AB_dic[gene_bin_coord] == 'NA'):
                gene_comp_NA = 1
            pass
        print("%d"%gene_comp_A+'\t'+"%d"%gene_comp_B+'\t'+"%d"%gene_comp_NA)

        if(gene_comp_A == 1 and gene_comp_B == 0 and gene_comp_NA == 0):
            gene_final_comp = "A"
        if (gene_comp_A == 0 and gene_comp_B == 1 and gene_comp_NA == 0):
            gene_final_comp = "B"
        if (gene_comp_A == 0 and gene_comp_B == 0 and gene_comp_NA == 1):
            gene_final_comp = "NA"
        if (gene_comp_A == 1 and gene_comp_B == 1 and gene_comp_NA == 0):
            gene_final_comp = "AB"
        if (gene_comp_A == 1 and gene_comp_B == 0 and gene_comp_NA == 1):
            gene_final_comp = "A0"
        if (gene_comp_A == 0 and gene_comp_B == 1 and gene_comp_NA == 1):
            gene_final_comp = "B0"
        if (gene_comp_A == 1 and gene_comp_B == 1 and gene_comp_NA == 1):
            gene_final_comp = "A0B"

        gene_compartment_list.writelines(line.strip()+'\t'+gene_final_comp+'\n')
        line_count = line_count +1
        print("line %d"%line_count)
    
    AB_list.close()
    gene_list.close()
    gene_compartment_list.close()


#Last同源片段的compartment判断
def Last_DNA_comp_judge(AB_comp_species1, AB_comp_species2, Last_bin_list, Resolution, Last_compartment_result):
    '''
    AB_comp_species1(/2)(无表头):染色体编号、start坐标、end坐标、AB区室（A/B/NA）
    Last_bin_list(有表头)：s1染色体编号、s1同源片段start坐标、s1同源片段end坐标、s1bin的start坐标、s1bin的end坐标、s1覆盖的bin数量、s2染色体编号、s2同源片段start坐标、s2同源片段end坐标、s2bin的start坐标、s2bin的end坐标、s2覆盖的bin数量
    Resolution:分析所用的矩阵数据的分辨率
    Last_compartment_result（无表头）：s1染色体编号、s1同源片段start坐标、s1同源片段end坐标、s1_bin1的区室、s1_bin2的区室、s2染色体编号、s2同源片段start坐标、s2同源片段end坐标、s2_bin1的区室、s2_bin2的区室
    *pal和peu的Last同源片段都是最多覆盖两个bin吗？（s1_bin1和s1_bin1）
    '''
    #compartment文件读入
    AB_list_s1=open("AB_comp_species1", "r")
    AB_list_s2=open("AB_comp_species2", "r")
    
    #Last_bin映射列表读入
    last_bin_list = open("Last_bin_list","r")
    
    #输出last片段对应compartment结果
    last_compartment_list= open("Last_compartment_result", "w+")
    
    #构建compartment字典
    AB_dic_s1 = {}
    for line in AB_list_s1:
        linelist = line.strip().split()
        bin_coord = linelist[0]+'-'+linelist[1]
        AB_dic_s1[bin_coord] = linelist[3]
    print("s1 Compartment字典构建完成，长度%d"%len(AB_dic_s1))

    AB_dic_s2 = {}
    for line in AB_list_s2:
        linelist = line.strip().split()
        bin_coord = linelist[0] + '-' + linelist[1]
        AB_dic_s2[bin_coord] = linelist[3]
    print("s2 Compartment字典构建完成，长度%d" % len(AB_dic_s2))
    
    #输出last片段Compartment结果
    next(last_bin_list)
    for line in last_bin_list:
        linelist = line.strip().split()
        if(linelist[5] == '1'):
            s1_bin1 = linelist[0]+'-'+linelist[3]
            s1_bin2 = s1_bin1
        if(linelist[5] == '2'):
            s1_bin1 = linelist[0] + '-' + linelist[3]
            s1_bin2 = linelist[0] + '-' + str(int(linelist[3])+Resolution)

        if(linelist[11] == '1'):
            s2_bin1 = linelist[6]+'-'+linelist[9]
            s2_bin2 = s2_bin1
        if(linelist[11] == '2'):
            s2_bin1 = linelist[6] + '-' + linelist[9]
            s2_bin2 = linelist[6] + '-' + str(int(linelist[9])+Resolution)

        '''
        if(AB_dic_s1[s1_bin1]=AB_dic_s1[s1_bin2]):
            s1_final_AB=AB_dic_s1[s1_bin1]
        else:
            s1_final_AB=AB_dic_s1[s1_bin1]+AB_dic_s1[s1_bin2]
        '''
        last_compartment_list.writelines(linelist[0]+'\t'+linelist[1]+'\t'+linelist[2]+'\t'+AB_dic_s1[s1_bin1]+'\t'+AB_dic_s1[s1_bin2]+'\t'+linelist[6]+'\t'+linelist[7]+'\t'+linelist[8]+'\t'+AB_dic_s2[s2_bin1]+'\t'+AB_dic_s2[s2_bin2]+'\n')
    
    AB_list_s1.close()
    AB_list_s2.close()
    last_bin_list.close()
    last_compartment_list.close()


#结构变异数据的compartment判断
def SV_comp_judge(AB_comp_species1, AB_comp_species2, SV_Inversion, SV_Translocation, SV_PAV_species1, SV_PAV_species2, Resolution, Inversion_compartment_result, Translocation_compartment_result, Species1_PAV_compartment, Species2_PAV_compartment):
    '''
    AB_comp_species1(/2)(无表头):染色体编号、start坐标、end坐标、AB区室（A/B/NA）
    SV_Inversion(/Translocation)(数据从第三行开始)：s1染色体编号、编号、基因开始坐标、基因结束坐标、结构变异类型、bin开始坐标、bin结束坐标、跨越的bin数、【重复前面的s2】
    SV_PAV_species1(/2)(数据从第三行开始)：染色体编号、基因开始坐标、基因结束坐标、结构变异类型、bin开始坐标、bin结束坐标、跨越的bin数
    Resolution：数据分辨率
    Inversion(/Translocation/Species1_PAV/Species2_PAV)_compartment_result:结果输出文件，在原来的数据最后加一列显示AB compartment划分
    '''
    #compartment文件读入
    s1_AB_list=open("AB_comp_species1", "r")
    s2_AB_list=open("AB_comp_species2", "r")
    
    #结构变异数据读入
    Inversion_list = open("SV_Inversion","r")
    Translocation_list = open("SV_Translocation","r")
    s1_PAV_list = open("SV_PAV_species1","r")
    s2_PAV_list = open("SV_PAV_species2","r")
    
    #输出基因对应compartment结果
    Inversion_compartment_list = open("Inversion_compartment_result","w+")
    Translocation_compartment_list = open("Translocation_compartment_result","w+")
    s1_PAV_compartment_list = open("Species1_PAV_compartment","w+")
    s2_PAV_compartment_list = open("Species2_PAV_compartment","w+")
    
    #构建compartment字典
    s1_AB_dic = {}
    for line in s1_AB_list:
        linelist = line.strip().split('\t')
        bin_coord = linelist[0]+'-'+linelist[1]
        s1_AB_dic[bin_coord] = linelist[3]
    print("s1_Compartment字典构建完成，长度%d"%len(s1_AB_dic))

    s2_AB_dic = {}
    for line in s2_AB_list:
        linelist = line.strip().split()
        bin_coord = linelist[0] + '-' + linelist[1]
        s2_AB_dic[bin_coord] = linelist[3]
    print("s2_Compartment字典构建完成，长度%d" % len(s2_AB_dic))
    
    #输出基因对应Compartment结果
    next(Inversion_list)
    next(Inversion_list)
    Inversion_line_count = 0
    for line in Inversion_list:
        linelist = line.strip().split()

        #初始化Compartmen标记
        s1_comp_A = 0
        s1_comp_B = 0
        s1_comp_NA = 0
        s1_final_comp = " "

        s2_comp_A = 0
        s2_comp_B = 0
        s2_comp_NA = 0
        s2_final_comp = " "

        for i in range(0,int(linelist[7])):
            s1_bin_coord = linelist[0]+"-"+str(int(linelist[5])+(i*Resolution))
            if (s1_AB_dic[s1_bin_coord] == 'A'):
                s1_comp_A = 1
            if (s1_AB_dic[s1_bin_coord] == 'B'):
                s1_comp_B = 1
            if (s1_AB_dic[s1_bin_coord] == 'NA'):
                s1_comp_NA = 1
            pass

        for j in range(0,int(linelist[15])):
            s2_bin_coord = linelist[8]+"-"+str(int(linelist[13])+(j*Resolution))

            if (s2_AB_dic[s2_bin_coord] == 'A'):
                s2_comp_A = 1
            if (s2_AB_dic[s2_bin_coord] == 'B'):
                s2_comp_B = 1
            if (s2_AB_dic[s2_bin_coord] == 'NA'):
                s2_comp_NA = 1
            pass

        if (s1_comp_A == 1 and s1_comp_B == 0 and s1_comp_NA == 0):
            s1_final_comp = "A"
        if (s1_comp_A == 0 and s1_comp_B == 1 and s1_comp_NA == 0):
            s1_final_comp = "B"
        if (s1_comp_A == 0 and s1_comp_B == 0 and s1_comp_NA == 1):
            s1_final_comp = "NA"
        if (s1_comp_A == 1 and s1_comp_B == 1 and s1_comp_NA == 0):
            s1_final_comp = "AB"
        if (s1_comp_A == 1 and s1_comp_B == 0 and s1_comp_NA == 1):
            s1_final_comp = "A0"
        if (s1_comp_A == 0 and s1_comp_B == 1 and s1_comp_NA == 1):
            s1_final_comp = "B0"
        if (s1_comp_A == 1 and s1_comp_B == 1 and s1_comp_NA == 1):
            s1_final_comp = "A0B"

        if (s2_comp_A == 1 and s2_comp_B == 0 and s2_comp_NA == 0):
            s2_final_comp = "A"
        if (s2_comp_A == 0 and s2_comp_B == 1 and s2_comp_NA == 0):
            s2_final_comp = "B"
        if (s2_comp_A == 0 and s2_comp_B == 0 and s2_comp_NA == 1):
            s2_final_comp = "NA"
        if (s2_comp_A == 1 and s2_comp_B == 1 and s2_comp_NA == 0):
            s2_final_comp = "AB"
        if (s2_comp_A == 1 and s2_comp_B == 0 and s2_comp_NA == 1):
            s2_final_comp = "A0"
        if (s2_comp_A == 0 and s2_comp_B == 1 and s2_comp_NA == 1):
            s2_final_comp = "B0"
        if (s2_comp_A == 1 and s2_comp_B == 1 and s2_comp_NA == 1):
            s2_final_comp = "A0B"

        Inversion_compartment_list.writelines(line +'\t' + s1_final_comp + '\t' + s2_final_comp + '\n')
        Inversion_line_count = Inversion_line_count +1
        print("Inversion_line: %d"%Inversion_line_count)

    next(Translocation_list)
    next(Translocation_list)
    Translocation_line_count = 0
    for line in Translocation_list:
        linelist = line.strip().split()

        #初始化Compartmen标记
        s1_comp_A = 0
        s1_comp_B = 0
        s1_comp_NA = 0
        s1_final_comp = " "

        s2_comp_A = 0
        s2_comp_B = 0
        s2_comp_NA = 0
        s2_final_comp = " "

        for i in range(0,int(linelist[7])):
            s1_bin_coord = linelist[0]+"-"+str(int(linelist[5])+(i*Resolution))
            if (s1_AB_dic[s1_bin_coord] == 'A'):
                s1_comp_A = 1
            if (s1_AB_dic[s1_bin_coord] == 'B'):
                s1_comp_B = 1
            if (s1_AB_dic[s1_bin_coord] == 'NA'):
                s1_comp_NA = 1
            pass

        for j in range(0,int(linelist[15])):
            s2_bin_coord = linelist[8]+"-"+str(int(linelist[13])+(j*Resolution))

            if (s2_AB_dic[s2_bin_coord] == 'A'):
                s2_comp_A = 1
            if (s2_AB_dic[s2_bin_coord] == 'B'):
                s2_comp_B = 1
            if (s2_AB_dic[s2_bin_coord] == 'NA'):
                s2_comp_NA = 1
            pass

        if (s1_comp_A == 1 and s1_comp_B == 0 and s1_comp_NA == 0):
            s1_final_comp = "A"
        if (s1_comp_A == 0 and s1_comp_B == 1 and s1_comp_NA == 0):
            s1_final_comp = "B"
        if (s1_comp_A == 0 and s1_comp_B == 0 and s1_comp_NA == 1):
            s1_final_comp = "NA"
        if (s1_comp_A == 1 and s1_comp_B == 1 and s1_comp_NA == 0):
            s1_final_comp = "AB"
        if (s1_comp_A == 1 and s1_comp_B == 0 and s1_comp_NA == 1):
            s1_final_comp = "A0"
        if (s1_comp_A == 0 and s1_comp_B == 1 and s1_comp_NA == 1):
            s1_final_comp = "B0"
        if (s1_comp_A == 1 and s1_comp_B == 1 and s1_comp_NA == 1):
            s1_final_comp = "A0B"

        if (s2_comp_A == 1 and s2_comp_B == 0 and s2_comp_NA == 0):
            s2_final_comp = "A"
        if (s2_comp_A == 0 and s2_comp_B == 1 and s2_comp_NA == 0):
            s2_final_comp = "B"
        if (s2_comp_A == 0 and s2_comp_B == 0 and s2_comp_NA == 1):
            s2_final_comp = "NA"
        if (s2_comp_A == 1 and s2_comp_B == 1 and s2_comp_NA == 0):
            s2_final_comp = "AB"
        if (s2_comp_A == 1 and s2_comp_B == 0 and s2_comp_NA == 1):
            s2_final_comp = "A0"
        if (s2_comp_A == 0 and s2_comp_B == 1 and s2_comp_NA == 1):
            s2_final_comp = "B0"
        if (s2_comp_A == 1 and s2_comp_B == 1 and s2_comp_NA == 1):
            s2_final_comp = "A0B"

        Translocation_compartment_list.writelines(line +'\t' + s1_final_comp + '\t' + s2_final_comp + '\n')
        Translocation_line_count = Translocation_line_count +1
        print("Translocation_line: %d"%Translocation_line_count)

    next(s1_PAV_list)
    next(s1_PAV_list)
    s1_PAV_line_count = 0
    for line in s1_PAV_list:
        linelist = line.strip().split()
        # 初始化Compartmen标记
        comp_A = 0
        comp_B = 0
        comp_NA = 0
        final_comp = " "
        for i in range(0,int(linelist[6])):
            bin_coord = linelist[0]+"-"+str(int(linelist[4])+(i*Resolution))
            if (s1_AB_dic[bin_coord] == 'A'):
                comp_A = 1
            if (s1_AB_dic[bin_coord] == 'B'):
                comp_B = 1
            if (s1_AB_dic[bin_coord] == 'NA'):
                comp_NA = 1
            pass

        if (comp_A == 1 and comp_B == 0 and comp_NA == 0):
            final_comp = "A"
        if (comp_A == 0 and comp_B == 1 and comp_NA == 0):
            final_comp = "B"
        if (comp_A == 0 and comp_B == 0 and comp_NA == 1):
            final_comp = "NA"
        if (comp_A == 1 and comp_B == 1 and comp_NA == 0):
            final_comp = "AB"
        if (comp_A == 1 and comp_B == 0 and comp_NA == 1):
            final_comp = "A0"
        if (comp_A == 0 and comp_B == 1 and comp_NA == 1):
            final_comp = "B0"
        if (comp_A == 1 and comp_B == 1 and comp_NA == 1):
            final_comp = "A0B"

        s1_PAV_compartment_list.writelines(line+'\t'+final_comp+'\n')
        s1_PAV_line_count = s1_PAV_line_count +1
        print("s1_PAV_line: %d"%s1_PAV_line_count)

    next(s2_PAV_list)
    next(s2_PAV_list)
    s2_PAV_line_count = 0
    for line in s2_PAV_list:
        linelist = line.strip().split()
        # 初始化Compartmen标记
        comp_A = 0
        comp_B = 0
        comp_NA = 0
        final_comp = " "
        for i in range(0,int(linelist[6])):
            bin_coord = linelist[0]+"-"+str(int(linelist[4])+(i*Resolution))
            if (s2_AB_dic[bin_coord] == 'A'):
                comp_A = 1
            if (s2_AB_dic[bin_coord] == 'B'):
                comp_B = 1
            if (s2_AB_dic[bin_coord] == 'NA'):
                comp_NA = 1
            pass

        if (comp_A == 1 and comp_B == 0 and comp_NA == 0):
            final_comp = "A"
        if (comp_A == 0 and comp_B == 1 and comp_NA == 0):
            final_comp = "B"
        if (comp_A == 0 and comp_B == 0 and comp_NA == 1):
            final_comp = "NA"
        if (comp_A == 1 and comp_B == 1 and comp_NA == 0):
            final_comp = "AB"
        if (comp_A == 1 and comp_B == 0 and comp_NA == 1):
            final_comp = "A0"
        if (comp_A == 0 and comp_B == 1 and comp_NA == 1):
            final_comp = "B0"
        if (comp_A == 1 and comp_B == 1 and comp_NA == 1):
            final_comp = "A0B"

        s2_PAV_compartment_list.writelines(line+'\t'+final_comp+'\n')
        s2_PAV_line_count = s2_PAV_line_count +1
        print("s2_PAV_line: %d"%s2_PAV_line_count)

    s1_AB_list.close()
    s2_AB_list.close()
    Inversion_list.close()
    Translocation_list.close()
    s1_PAV_list.close()
    s2_PAV_list.close()
    Inversion_compartment_list.close()
    Translocation_compartment_list.close()
    s1_PAV_compartment_list.close()
    s2_PAV_compartment_list.close()


#各染色体交互-距离统计
def chr_dist(Chr_intra_line_num, Chr_intra_matrix, Freqsum_dis_result, Resolution):
    '''
    Chr_intra_line_num:染色体编号，对应染色体互作矩阵能的行数（三元表格式矩阵）
    Chr_intra_matrix：（只有染色体内部互作的矩阵文件）bin1， bin2， 互作频率
    Freqsum_dis_result：（互作距离与交互频率的结果输出文件） 距离， 频率， 染色体
    '''
    #每条染色体的交互矩阵行数
    chr_intra_line=open(Chr_intra_line_num,"r")
    
    #染色体内部互作矩阵输入
    chr_intra_matrix=open(Chr_intra_matrix,"r")
    
    #距离-交互总合列表输出
    freqsum_dis_list=open(Freqsum_dis_result,"w+")
    
    #各染色体交互矩阵长度字典
    chr_line_dic = {}
    for line in chr_intra_line:
        list = line.strip().split()
        chr_line_dic[list[0]]=list[1]
    print(len(chr_line_dic))
    
    #构建距离交互总数字典
    for m in range(0,len(chr_line_dic)):
        chr_name = "Lachesis_group"+str(m)
        dist_contact_sum_dic = {}
        for n in range(0,int(chr_line_dic[chr_name])):
            line = chr_intra_matrix.readline()
            intra_list = line.strip().split('\t')
            intra_dist = (int(intra_list[1])-int(intra_list[0]))*Resolution
            if(dist_contact_sum_dic.__contains__(str(intra_dist)) == False):
                dist_contact_sum_dic[str(intra_dist)] = intra_list[2]
            else:
                dist_contact_sum_dic[str(intra_dist)] = str(float(dist_contact_sum_dic[str(intra_dist)])+float(intra_list[2]))
            #dist_contact_sum_dic['6666'] = str(0)
        print("Lachesis_group%d"%m+"距离交互总数字典构建完成，长度：%d"%len(dist_contact_sum_dic))

        #输出列表
        for i,j in dist_contact_sum_dic.items():
            list = '{i} {j}'.format(i=i, j=j)
            freqsum_dis_list.writelines(list+' '+chr_name+'\n')
        pass

    chr_intra_line.close()
    chr_intra_matrix.close()
    freqsum_dis_list.close()


#OE矩阵生成
def OE_matrix_gen(Matrix_bed, Chr_intra_matrix, Chr_num, Chr_OE_matrix):
    '''
    Matrix_bed:染色体名字，bin_start, bin_end, bin编号
    Chr_intra_matrix：（只有染色体内部互作的矩阵文件）bin1，bin2，互作频率
    Chr_num=19
    Chr_OE_matrix：（OE矩阵输出文件）bin1，bin2，OE互作频率
    '''
    #bed文件读入
    bed=open(Matrix_bed,"r")
    
    #染色体内部互作矩阵输入
    chr_intra_matrix=open(Chr_intra_matrix,"r")
    
    #OE矩阵输出
    OE_matrix=open(Chr_OE_matrix,"w+")
    
    #构建染色体基因座数量字典
    bed_dic = {}
    for line in bed:
        bed_list = line.strip().split('\t')
        if (bed_dic.__contains__(bed_list[0]) == False):
            line_count = 0
            bed_dic[bed_list[0]] = str(line_count)
        if (bed_dic.__contains__(bed_list[0]) == True):
            line_count = line_count + 1
            bed_dic[bed_list[0]] = str(line_count)
    print("染色体基因座数量字典构建完成，长度：%d"%len(bed_dic))
    #print(bed_dic)
    
    #构建距离交互总数字典
    dist_contact_sum_dic = {}
    for line in chr_intra_matrix:
        intra_list = line.strip().split('\t')
        intra_dist = abs(int(intra_list[1])-int(intra_list[0]))
        if(dist_contact_sum_dic.__contains__(str(intra_dist)) == False):
            dist_contact_sum_dic[str(intra_dist)] = intra_list[2]
        else:
            dist_contact_sum_dic[str(intra_dist)] = str(float(dist_contact_sum_dic[str(intra_dist)])+float(intra_list[2]))
    print("距离交互总数字典构建完成，长度：%d"%len(dist_contact_sum_dic))
    #print(dist_contact_sum_dic)
    
    #构建距离期望字典
    expect_dic = {}
    for i in range (0,len(dist_contact_sum_dic)):
        dis_count = 0
        for j in range(0,Chr_num):
            chr_name = "Lachesis_group%d"%j
            if(i<int(bed_dic[chr_name])):
                dis_count = dis_count+(int(bed_dic[chr_name])-i)
            pass

        expect_dic[str(i)] = str(float(dist_contact_sum_dic[str(i)])/dis_count)
        pass
    print("期望交互字典构建完成，长度：%d"%len(expect_dic))
    #print(expect_dic)
    
    #生成OE矩阵
    chr_intra_matrix.seek(0)
    line_count = 0
    for line in chr_intra_matrix:
        intra_list = line.strip().split('\t')
        intra_dist = str(int(intra_list[1])-int(intra_list[0]))
        OE_value = float(intra_list[2])/float(expect_dic[intra_dist])
        OE_matrix.writelines(intra_list[0]+'\t'+intra_list[1]+'\t'+str(OE_value)+'\n')
        line_count = line_count+1
        print("line: %d" % line_count)
    
    bed.close()
    chr_intra_matrix.close()
    OE_matrix.close()


#WGD累计交互得分计算
def WGD_freq_score(WGD_bed, WGD_TPM_GT2, WGD_TPM_LT2, OE_matrix, Resolution, WGD_TPM_GT2_freq, WGD_TPM_LT2_freq, WGD_TPM_GT2_draw, WGD_TPM_LT2_draw):
    '''
    bed文件：染色体编号-bin起始坐标、bin编号
    WGD_TPM_GT2(LT2)：有表头、WGD基因对的TPM值的倍数大于两倍（小于两倍）的文件。基因1编号、染色体编号、起始bin坐标、跨越的bin数量、基因2编号、染色体编号、起始bin坐标、跨越的bin数量、差异倍数、Left/Right（左边的TPM值大/右边的TPM值大）、
    OE_matrix：距离标准化矩阵。bin1编号、bin2编号、互作频率。
    Resolution=10000：距离标准化互作矩阵分辨率。
    WGD_TPM_GT2(LT2)_freq：WGD基因对的TPM值的倍数大于两倍（小于两倍）的互作得分。有表头。基因编号（高TPM）、总互作频率、互作频次、平均互作频率、基因编号（低TPM）、总互作频率、互作频次、平均互作频率。
    WGD_TPM_GT2(LT2)_draw：画图用数据。有表头。基因编号（高TPM）、平均互作频率、基因编号（低TPM）、平均互作频率。
    '''
    #bed文件读入
    bed = open(WGD_bed,"r")
    #WGD_TPM差异倍数分级数据读入
    WGD_TPM_gt2 = open(WGD_TPM_GT2,"r")
    WGD_TPM_lt2 = open(WGD_TPM_LT2,"r")
    #距离矫正矩阵读入
    dist_norm_matrix = open(OE_matrix,"r")
    
    #WGD_TPM_差异倍数分级交互水平数据输出
    WGD_TPM_gt2_contact = open(WGD_TPM_GT2_freq,"w+")
    WGD_TPM_lt2_contact = open(WGD_TPM_LT2_freq,"w+")

    WGD_TPM_gt2_contact.writelines("gene_ID_hTPM"+'\t'+"frequency_sum"+'\t'+"frequency_count"+'\t'+"average_frequency"+'\t'+"gene_ID_lTPM"+'\t'+"frequency_sum"+'\t'+"frequency_count"+'\t'+"average_frequency"+'\n')
    WGD_TPM_lt2_contact.writelines("gene_ID_hTPM"+'\t'+"frequency_sum"+'\t'+"frequency_count"+'\t'+"average_frequency"+'\t'+"gene_ID_lTPM"+'\t'+"frequency_sum"+'\t'+"frequency_count"+'\t'+"average_frequency"+'\n')
    
    #绘图用文件输出
    WGD_TPM_gt2_draw = open(WGD_TPM_GT2_draw,"w+")
    WGD_TPM_lt2_draw = open(WGD_TPM_LT2_draw,"w+")

    WGD_TPM_gt2_draw.writelines("gene_ID_h"+'\t'+"average_frequency_h"+'\t'+"gene_ID_l"+'\t'+"average_frequency_l"+'\n')
    WGD_TPM_lt2_draw.writelines("gene_ID_h"+'\t'+"average_frequency_h"+'\t'+"gene_ID_l"+'\t'+"average_frequency_l"+'\n')
    
    #根据bed文件构建坐标字典
    bed_temp_dic = []
    for line in bed:
        list = line.strip().split('\t')
        bed_temp_dic.append(list)
    bed_dic = dict(bed_temp_dic)
    print(len(bed_dic))
    print('坐标字典构建完成，长度：',len(bed_dic))

    #构建距离矫正矩阵字典
    matrix_dic = {}
    for line in dist_norm_matrix:
        list = line.strip().split('\t')
        str = list[0] + ',' + list[1]
        matrix_dic[str] = list[2]
    print('矩阵字典构建完成，长度：%d'%len(matrix_dic))

    #根据字典确认WGD基因累计交互得分
    next(WGD_TPM_gt2)
    for line in WGD_TPM_gt2:
        list = line.strip().split('\t')
        left_sum_final = 0
        right_sum_final = 0
        left_average_final = 0
        left_average_final = 0

        for i in range(0, int(list[3])):
            left_contact_sum = 0
            left_contact_count = 0
            left_average_contact = 0

            left_bin_str = list[1] + '-%d' % (i * Resolution + int(list[2]))
            left_coord = bed_dic[left_bin_str]
            print(left_coord)

            for j in range(1, len(bed_dic) + 1):
                matrix_temp_str1 = '%s' % left_coord + ',%d' % j
                matrix_temp_str2 = '%d' % j + ',%s' % left_coord

                if (matrix_dic.__contains__(matrix_temp_str1) == True and matrix_dic.__contains__(matrix_temp_str2) == False):
                    left_contact_sum = left_contact_sum + float(matrix_dic[matrix_temp_str1])
                    left_contact_count = left_contact_count + 1
                if (matrix_dic.__contains__(matrix_temp_str1) == False and matrix_dic.__contains__(matrix_temp_str2) == True):
                    left_contact_sum = left_contact_sum + float(matrix_dic[matrix_temp_str2])
                    left_contact_count = left_contact_count + 1
                if (matrix_dic.__contains__(matrix_temp_str1) == True and matrix_dic.__contains__(matrix_temp_str2) == True):
                    left_contact_sum = left_contact_sum + float(matrix_dic[matrix_temp_str2])
                    left_contact_count = left_contact_count + 1
                pass
            pass
            if (left_contact_count != 0):
                left_average_contact = left_contact_sum / left_contact_count
            if (left_contact_count == 0):
                left_average_contact = 0
            print(left_average_contact)
            left_sum_final = left_sum_final+left_average_contact
        left_average_final = left_sum_final/int(list[3])

        for i in range(0, int(list[7])):
            right_contact_sum = 0
            right_contact_count = 0
            right_average_contact = 0
            right_bin_str = list[5] + '-%d' % (i * Resolution + int(list[6]))
            right_coord = bed_dic[right_bin_str]
            print(right_coord)

            for j in range(1, len(bed_dic) + 1):
                matrix_temp_str1 = '%s' % right_coord + ',%d' % j
                matrix_temp_str2 = '%d' % j + ',%s' % right_coord

                if (matrix_dic.__contains__(matrix_temp_str1) == True and matrix_dic.__contains__(matrix_temp_str2) == False):
                    right_contact_sum = right_contact_sum + float(matrix_dic[matrix_temp_str1])
                    right_contact_count = right_contact_count + 1
                if (matrix_dic.__contains__(matrix_temp_str1) == False and matrix_dic.__contains__(matrix_temp_str2) == True):
                    right_contact_sum = right_contact_sum + float(matrix_dic[matrix_temp_str2])
                    right_contact_count = right_contact_count + 1
                if (matrix_dic.__contains__(matrix_temp_str1) == True and matrix_dic.__contains__(matrix_temp_str2) == True):
                    right_contact_sum = right_contact_sum + float(matrix_dic[matrix_temp_str2])
                    right_contact_count = right_contact_count + 1
                pass
            pass
            if (right_contact_count != 0):
                right_average_contact = right_contact_sum / right_contact_count
            if (right_contact_count == 0):
                right_average_contact = 0
            print(right_average_contact)
            right_sum_final = right_sum_final + right_average_contact
        right_average_final = right_sum_final / int(list[7])

        if (list[9] == "Left"):
            WGD_TPM_gt2_contact.writelines(list[0] + '\t%.10f' % left_contact_sum + '\t%d' % left_contact_count + '\t%.10f' %left_average_final + '\t%s' % list[4] + '\t%.10f' % right_contact_sum + '\t%d' %right_contact_count + '\t%.10f' % right_average_final + '\n')
            WGD_TPM_gt2_draw.writelines(list[0] + '\t%.10f'%left_average_final+'\t'+ list[4]+ '\t%.10f'%right_average_final+'\n')

        if (list[9] == "Right"):
            WGD_TPM_gt2_contact.writelines(list[4] + '\t%.10f' % right_contact_sum + '\t%d' % right_contact_count + '\t%.10f' %right_average_final + '\t%s' % list[0] + '\t%.10f' % left_contact_sum + '\t%d' %left_contact_count + '\t%.10f' % left_average_final + '\n')
            WGD_TPM_gt2_draw.writelines(list[4] + '\t%.10f'%right_average_final+'\t'+ list[0]+ '\t%.10f'%left_average_final+'\n')

    next(WGD_TPM_lt2)
    for line in WGD_TPM_lt2:
        list = line.strip().split('\t')

        left_sum_final = 0
        right_sum_final = 0
        left_average_final = 0
        left_average_final = 0

        for i in range(0, int(list[3])):
            left_contact_sum = 0
            left_contact_count = 0
            left_average_contact = 0

            left_bin_str = list[1] + '-%d' % (i * Resolution + int(list[2]))
            left_coord = bed_dic[left_bin_str]
            print(left_coord)

            for j in range(1, len(bed_dic) + 1):
                matrix_temp_str1 = '%s' % left_coord + ',%d' % j
                matrix_temp_str2 = '%d' % j + ',%s' % left_coord

                if (matrix_dic.__contains__(matrix_temp_str1) == True and matrix_dic.__contains__(matrix_temp_str2) == False):
                    left_contact_sum = left_contact_sum + float(matrix_dic[matrix_temp_str1])
                    left_contact_count = left_contact_count + 1
                if (matrix_dic.__contains__(matrix_temp_str1) == False and matrix_dic.__contains__(matrix_temp_str2) == True):
                    left_contact_sum = left_contact_sum + float(matrix_dic[matrix_temp_str2])
                    left_contact_count = left_contact_count + 1
                if (matrix_dic.__contains__(matrix_temp_str1) == True and matrix_dic.__contains__(matrix_temp_str2) == True):
                    left_contact_sum = left_contact_sum + float(matrix_dic[matrix_temp_str2])
                    left_contact_count = left_contact_count + 1
                pass
            pass
            if (left_contact_count != 0):
                left_average_contact = left_contact_sum / left_contact_count
            if (left_contact_count == 0):
                left_average_contact = 0
            print(left_average_contact)
            left_sum_final = left_sum_final+left_average_contact
        left_average_final = left_sum_final/int(list[3])

        for i in range(0, int(list[7])):
            right_contact_sum = 0
            right_contact_count = 0
            right_average_contact = 0

            right_bin_str = list[5] + '-%d' % (i * Resolution + int(list[6]))
            right_coord = bed_dic[right_bin_str]
            print(right_coord)

            for j in range(1, len(bed_dic) + 1):
                matrix_temp_str1 = '%s' % right_coord + ',%d' % j
                matrix_temp_str2 = '%d' % j + ',%s' % right_coord

                if (matrix_dic.__contains__(matrix_temp_str1) == True and matrix_dic.__contains__(matrix_temp_str2) == False):
                    right_contact_sum = right_contact_sum + float(matrix_dic[matrix_temp_str1])
                    right_contact_count = right_contact_count + 1
                if (matrix_dic.__contains__(matrix_temp_str1) == False and matrix_dic.__contains__(matrix_temp_str2) == True):
                    right_contact_sum = right_contact_sum + float(matrix_dic[matrix_temp_str2])
                    right_contact_count = right_contact_count + 1
                if (matrix_dic.__contains__(matrix_temp_str1) == True and matrix_dic.__contains__(matrix_temp_str2) == True):
                    right_contact_sum = right_contact_sum + float(matrix_dic[matrix_temp_str2])
                    right_contact_count = right_contact_count + 1
                pass
            pass
            if (right_contact_count != 0):
                right_average_contact = right_contact_sum / right_contact_count
            if (right_contact_count == 0):
                right_average_contact = 0
            print(right_average_contact)
            right_sum_final = right_sum_final + right_average_contact
        right_average_final = right_sum_final / int(list[7])

        if (list[9] == "Left"):
            WGD_TPM_lt2_contact.writelines(list[0] + '\t%.10f' % left_contact_sum + '\t%d' % left_contact_count + '\t%.10f' %left_average_final + '\t%s' % list[4] + '\t%.10f' % right_contact_sum + '\t%d' %right_contact_count + '\t%.10f' % right_average_final + '\n')
            WGD_TPM_lt2_draw.writelines(list[0] + '\t%.10f'%left_average_final+'\t'+ list[4]+ '\t%.10f'%right_average_final+'\n')

        if (list[9] == "Right"):
            WGD_TPM_lt2_contact.writelines(list[4] + '\t%.10f' % right_contact_sum + '\t%d' % right_contact_count + '\t%.10f' %right_average_final + '\t%s' % list[0] + '\t%.10f' % left_contact_sum + '\t%d' %left_contact_count + '\t%.10f' % left_average_final + '\n')
            WGD_TPM_lt2_draw.writelines(list[4] + '\t%.10f'%right_average_final+'\t'+ list[0]+ '\t%.10f'%left_average_final+'\n')

    bed.close()
    WGD_TPM_gt2.close()
    WGD_TPM_lt2.close()
    dist_norm_matrix.close()
    WGD_TPM_gt2_draw.close()
    WGD_TPM_lt2_draw.close()
    WGD_TPM_gt2_contact.close()
    WGD_TPM_lt2_contact.close()


#重复序列密度计算
def Repeat_seq_density(Repeat_seq, Repeat_seq_density):
    '''
    Repeat_seq：
    Repeat_seq_density：
    '''
    #重复序列文件读入
    repeat_list = open(Repeat_seq,"r")
    #重复序列密度文件输出
    repet_density_list=open(Repeat_seq_density, "w+")
    
    for line in repeat_list:
        linelist = line.strip().split('\t')
        if(int(linelist[8])==1):
            repet_density_list.writelines(linelist[0]+'\t'+linelist[1]+'\t'+linelist[2]+'\t'+linelist[3]+'\t'+linelist[4]+'\t'+linelist[5]+'\t'+linelist[6]+'\t'+linelist[7]+'\t'+linelist[8]+'\t'+linelist[9]+'\n')
        if(int(linelist[8])==2):
            repet_density_list.writelines(linelist[0]+'\t'+linelist[1]+'\t'+linelist[2]+'\t'+linelist[3]+'\t'+linelist[4]+'\t'+linelist[5]+'\t'+linelist[6]+'\t'+str(int(linelist[6])+50000)+'\t'+linelist[8]+'\t'+linelist[9]+'\n')
            repet_density_list.writelines(linelist[0]+'\t'+linelist[1]+'\t'+linelist[2]+'\t'+linelist[3]+'\t'+linelist[4]+'\t'+linelist[5]+'\t'+str(int(linelist[6])+50000)+'\t'+linelist[7]+'\t'+linelist[8]+'\t'+linelist[10]+'\n')
        print(linelist)

    repeat_list.close()
    repet_density_list.close()


#保守TAD中同源基因ID提取
def Conserved_TAD_orthgeneid(Conserved_TAD_gene, Conserved_TAD_geneid):
    '''
    Conserved_TAD_gene：
    Conserved_TAD_geneid：
    '''
    #读入保守TAD基因
    conserved_TAD_gene = open(Conserved_TAD_gene,"r")
    #写保守TAD基因编号
    conserved_TAD_gene_list = open(Conserved_TAD_geneid,"w+")
    final_list = []
    for line in conserved_TAD_gene:
        line_list = line.strip().split('\t')
        for i in range(0,len(line_list)):
            if(line_list[i] not in final_list):
                final_list.append(line_list[i])
    print(final_list)
    print(len(final_list))

    for q in range(0,len(final_list)):
        conserved_TAD_gene_list.writelines(final_list[q]+'\n')

    conserved_TAD_gene.close()
    conserved_TAD_gene_list.close()


#直系同源基因TAD保守分析


#在二维字典添加元素的函数定义
def addtwodimdict(thedict, key_a, key_b, val):
    adic=thedict.keys()
    if key_a in adic:
        thedict[key_a].update({key_b: val})
    else:
        thedict.update({key_a:{key_b: val}})


#计算WGD基因对的互作频率
def WGD_gene_contact_freq(WGD_genepair, Contact_matrix, WGD_gene_freq):
    '''
    WGD_genepair：WGD基因对的坐标文件，有表头。基因1编号、染色体编号、基因1坐标起点、基因1结束坐标、基因2编号、染色体编号、基因2坐标起点、基因2结束坐标、基因1起始bin编号、基因1结束bin编号、基因1跨越的bin数、基因2起始bin编号、基因2结束bin编号、基因2跨越的bin数。
    Contact_matrix：互作矩阵。bin1、bin2、互作频率。
    WGD_gene_freq：WGD基因对互作频率输出文件，基因1起始bin编号、基因1结束bin编号、基因2起始bin编号、基因2结束bin编号、全部互作频率、互作频次、平均互作频率
    '''
    #读入WGD基因对坐标文件，计算WGD基因对的对数
    interpair=open(WGD_genepair,"r")
    WGD_len=len(interpair.readlines())-1
    interpair.seek(0)
    print('WGD_len: %d'%WGD_len)

    #读入互作频率
    contact_matrix=open(Contact_matrix,"r")

    #用互作矩阵创建二维字典
    matrix_dic = {}
    for line in contact_matrix:
        list = line.strip().split('\t')
        addtwodimdict(matrix_dic,int(list[0]),int(list[1]),float(list[2]))
    print('contact matrix dic finish, length: %d'%len(matrix_dic))

    #构建基因的bin对的矩阵
    gene_m_freq=np.zeros((WGD_len, 7)).astype(int)

    next(interpair)
    i=0
    for line in interpair:
        list = line.strip().split('\t')
        gene_m_freq[i,0]=int(list[8])
        gene_m_freq[i,1]=int(list[9])
        gene_m_freq[i,2]=int(list[11])
        gene_m_freq[i,3]=int(list[12])
        i=i+1

    #计算基因对的交互频率
    for i in range(WGD_len):
        for j in range(gene_m_freq[i,0],gene_m_freq[i,1]+1):
            for k in range(gene_m_freq[i,2],gene_m_freq[i,3]+1):
                if j<k:
                    if j in matrix_dic.keys():
                        if k in matrix_dic[j].keys():
                            gene_m_freq[i,4]=gene_m_freq[i,4]+matrix_dic[j][k]
                            gene_m_freq[i,5]=gene_m_freq[i,5]+1
                else:
                    if k in matrix_dic.keys():
                        if j in matrix_dic[k].keys():
                            gene_m_freq[i,4]=gene_m_freq[i,4]+matrix_dic[k][j]
                            gene_m_freq[i,5]=gene_m_freq[i,5]+1
        if gene_m_freq[i,5]>0:
            gene_m_freq[i,6]=math.ceil(gene_m_freq[i,4]/gene_m_freq[i,5])
    print('finish!')
    np.savetxt(WGD_gene_freq,gene_m_freq,fmt='%d',delimiter='\t')

    interpair.close()
    contact_matrix.close()


#计算TAD边界的基因密度
def TAD_bound_gene_density(Gene_coord, TAD, Window_num, Window_size, Group, Gene_density_file):
    '''
    Gene_coord, TAD, Window_num=60, Window_size=10000, Group=4, Gene_density_file
    Gene_coord：（按照基因的TPM表达量从低到高排列）基因编号、染色体编号、基因起始坐标、基因结束坐标。
    TAD：染色体编号、TAD起点坐标、TAD结束坐标。
    Window_num：总共窗口数量。
    Window_size=10000：窗口大小。
    Group：所有基因划分的组数。
    Gene_density_file：输出文件，每个窗口的平均基因数量。
    '''
    #读入基因坐标文件、TAD文件
    gene_list=open(Gene_coord,"r")
    TAD_list=open(TAD,"r")
    #计算基因、TAD数量
    gene_num=len(gene_list.readlines())
    gene_list.seek(0)
    TAD_num=len(TAD_list.readlines())
    TAD_list.seek(0)
    
    #计算每组计算的数量大小
    group_size=round(gene_num/Group)
    #创建TAD边界基因密度矩阵
    gene_density=np.zeros((Group, Window_num)).astype(int)
    
    for index, line in enumerate(gene_list):
        gene=line.strip().split()
        #计算基因所属组号
        g=math.floor(index/group_size)
        gene[2]=int(gene[2])
        gene[3]=int(gene[3])
        if g>=Group:
            g=Group-1
        for line in TAD_list:
            TAD=line.strip().split()
            TAD[1]=int(TAD[1])
            TAD[2]=int(TAD[2])
            TAD_start=TAD[1]-Window_num*Window_size/2
            if gene[1]==TAD[0]:
                for i in range(Window_num+1):
                    if (gene[2]<(TAD_start+i*Window_size)) and (gene[3]<=(TAD_start+i*Window_size)):
                        if i==0:
                            break
                        else:
                            gene_density[g,i-1]=gene_density[g,i-1]+1
                            break
                    elif (gene[2]<(TAD_start+i*Window_size)) and (gene[3]>(TAD_start+i*Window_size)) and (i!=0):
                        gene_density[g,i-1]=gene_density[g,i-1]+1
        TAD_list.seek(0)
    
    gene_density_2=gene_density/TAD_num
    np.savetxt(Gene_density_file,gene_density_2,fmt='%.05f',delimiter='\t')
    
    gene_list.close()
    TAD_list.close()



