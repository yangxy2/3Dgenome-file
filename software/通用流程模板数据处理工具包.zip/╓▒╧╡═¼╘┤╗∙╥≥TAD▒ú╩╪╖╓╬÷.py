import numpy as np
import pandas as pd


# 模块化
class GetTADGene(object):
    def __init__(self, t_name, g_name):
        self.tad_name = t_name
        self.gene_name = g_name
        self.read_TAD()
        self.read_Gene()

    # 读取TAD文件
    def read_TAD(self):
        self.tad = pd.read_csv(self.tad_name)

    # 读取基因文件
    def read_Gene(self):
        self.gene = pd.read_csv(self.gene_name)

    # 获取特定染色体中,某一范围内的所有基因编号
    def get_all_gene_between(self, lid, start, end):
        # 获取特定染色体的基因
        lgene = self.gene[self.gene["Lachesis_group_ID"] == lid]
        # print(lgene)
        temp = lgene[lgene["start"] < end]
        temp = temp[temp["end"] > start]
        ans = []
        for index, row in temp.iterrows():
            ans.append(row["num"])
        return sorted(ans)

    # 计算每一个TAD中的基因编号,并且构成字典结构
    def gene_in_tad(self):
        ans = {}
        index = 0
        for index, row in self.tad.iterrows():
            tid = row["ID"]
            lid = row["Lachesis_group_ID"]
            start = int(row["start"])
            end = int(row["end"])
            genes = self.get_all_gene_between(lid, start, end)
            ans[tid] = genes
        self.tad_num = index + 1
        return ans


    def start(self):
        self.ans = self.gene_in_tad()
        return self.ans


# 用于判断两个列表的相似度是否大于某一阈值
def is_list_likely(l1: list, l2: list, th=0.7):
    if len(l1) == 0 or len(l2) == 0:
        return 0
    l1, l2 = list(l1), list(l2)
    l1, l2 = sorted(l1), sorted(l2)
    long = l2 if len(l2) > len(l1) else l1
    short = l2 if len(l2) <= len(l1) else l1
    max_len = len(long)
    min_len = len(short)
    counter = 0
    for e in short:
        if e in long:
            counter = counter + 1
    return ((counter*2)/(max_len+min_len)) if ((counter*2)/(max_len+min_len)) >= th else False


# 计算相同的数目
def dic_counter(d1: dict, d2):
    ans = []
    temp = []
    counter = 0
    d1_value = tuple(d1.values())
    d2_value = tuple(d2.values())
    for i in d1_value:
        for j in d2_value:
            if is_list_likely(i, j) and min(len(i), len(j)) > 5:
                counter = counter + 1
                temp.append(i)
                d1_key = list(d1.keys())[list(d1.values()).index(i)]
                d2_key = list(d2.keys())[list(d2.values()).index(j)]
                ans.append([d1_key, d2_key])
                continue
    return ans


if __name__ == '__main__':
    print("Hello World!\n\n\n")
    pal = GetTADGene("2020new/TAD_pal.csv", "2020new/Pal_orthologous_gene_with_num.csv")
    pal.start()
    peu = GetTADGene("2020new/TAD_peu.csv", "2020new/Peu_orthologous_gene_with_num.csv")
    peu.start()

    ans = dic_counter(pal.ans, peu.ans)

    pal_aim = pal.tad[pal.tad["ID"].isin([_[0] for _ in ans])]
    peu_aim = peu.tad[peu.tad["ID"].isin([_[1] for _ in ans])]

    test1 = pal.an
    print(pal.ans)
    with open('2020new/Pal_TAD_gene.csv', 'w') as f1:
        [f1.write('{0},{1}\n'.format(key, value)) for key, value in pal.ans.items()]

    print(peu.ans)
    with open('2020new/Peu_TAD_gene.csv', 'w') as f2:
        [f2.write('{0},{1}\n'.format(key, value)) for key, value in peu.ans.items()]
    '''pal_aim.to_csv("2020new/pal_out_new_gene_th70_ab5.csv")
    peu_aim.to_csv("2020new/peu_out_new_gene_th70_ab5.csv")'''

    pass
